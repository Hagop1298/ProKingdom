import "./App.css";
import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import MainTable from "./component/table";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import SignIn from "./SignIn/signIn";
import Home from "./component/home";

// const supabase = createClient(
//   "https://tgpucbwkqhwocqvvwbvm.supabase.co/rest/v1/governors?select=*",
//   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRncHVjYndrcWh3b2NxdnZ3YnZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODk5NTYzMTUsImV4cCI6MjAwNTUzMjMxNX0.bd2zr1eCbTAvUfyHR5HBIVm3zUv9Yw2b7OVT5zOejzc"
// );
function App() {
  return (
    <>
      <div className="w-full flex flex-col items-center backround-color">
        {/* <div className="bg-white self-stretch flex w-full flex-col justify-center pl-8 pr-16 py-1.5 items-start max-md:max-w-full max-md:px-5">
          <img
            loading="lazy"
            srcSet="https://cdn.builder.io/api/v1/image/assets/TEMP/1be80f537e2bf9596ee29b00b5aa9724af310d01fc10cdbecdff1d53a25311fd?apiKey=f28582526909464db7f31fc277be89ee&width=100 100w, https://cdn.builder.io/api/v1/image/assets/TEMP/1be80f537e2bf9596ee29b00b5aa9724af310d01fc10cdbecdff1d53a25311fd?apiKey=f28582526909464db7f31fc277be89ee&width=200 200w, https://cdn.builder.io/api/v1/image/assets/TEMP/1be80f537e2bf9596ee29b00b5aa9724af310d01fc10cdbecdff1d53a25311fd?apiKey=f28582526909464db7f31fc277be89ee&width=400 400w, https://cdn.builder.io/api/v1/image/assets/TEMP/1be80f537e2bf9596ee29b00b5aa9724af310d01fc10cdbecdff1d53a25311fd?apiKey=f28582526909464db7f31fc277be89ee&width=800 800w, https://cdn.builder.io/api/v1/image/assets/TEMP/1be80f537e2bf9596ee29b00b5aa9724af310d01fc10cdbecdff1d53a25311fd?apiKey=f28582526909464db7f31fc277be89ee&width=1200 1200w, https://cdn.builder.io/api/v1/image/assets/TEMP/1be80f537e2bf9596ee29b00b5aa9724af310d01fc10cdbecdff1d53a25311fd?apiKey=f28582526909464db7f31fc277be89ee&width=1600 1600w, https://cdn.builder.io/api/v1/image/assets/TEMP/1be80f537e2bf9596ee29b00b5aa9724af310d01fc10cdbecdff1d53a25311fd?apiKey=f28582526909464db7f31fc277be89ee&width=2000 2000w, https://cdn.builder.io/api/v1/image/assets/TEMP/1be80f537e2bf9596ee29b00b5aa9724af310d01fc10cdbecdff1d53a25311fd?apiKey=f28582526909464db7f31fc277be89ee&"
            className="aspect-[2.96] object-contain object-center w-40 overflow-hidden max-w-full"
          />
        </div> */}

        <Router>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/signin" element={<SignIn />} />
          </Routes>
        </Router>
      </div>
    </>
  );
}

export default App;
