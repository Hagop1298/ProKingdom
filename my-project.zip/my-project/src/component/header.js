import React from "react";
import All from ".././Assets/icons/all.svg";
const Header = () => {
  return (
    <div>
      <span className="flex w-[1100px] max-w-full flex-col mt-32 px-5 items-start max-md:mt-10">
        {/* <div className="justify-center text-neutral-800 text-2xl font-semibold whitespace-nowrap">
          Map of #&123;C11001&125;
        </div>
        <span className="shadow-sm bg-white flex w-3/4 flex-col items-center mt-2 pl-4 pr-2.5 py-5 rounded-xl">
          <div className="text-black text-2xl">The Story</div>
          <div className="text-black text-base font-light mt-2.5">
            kvk.&123;kvk_Story&125;Lorem ispum Lorem ispumLorem ispum Lorem
            ispumLorem ispum Lorem ispumLorem ispum Lorem.ispumLorem ispum Lorem
            ispumLorem ispum Lorem ispumLorem ispum Lorem ispumLorem ispum{" "}
          </div>
        </span> */}

        {/* <div className="self-stretch flex items-stretch justify-between gap-5 mt-16 pr-3.5 max-md:max-w-full max-md:flex-wrap max-md:mt-10">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/6a2d116c9f6ba1828beb0fb04c224d6a4a5a59948b5fb727a4e8307910739961?apiKey=f28582526909464db7f31fc277be89ee&"
            className="aspect-[3.88] object-contain object-center w-[155px] overflow-hidden self-center shrink-0 max-w-full my-auto"
          />
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/74db1495cec0aa6a61aa3d1bfd27894aa7a6db51b2f80c13a46b0406b8dbcb0a?apiKey=f28582526909464db7f31fc277be89ee&"
            className="aspect-[8.04] object-contain object-center w-[402px] overflow-hidden"
          />
          <div className="self-center flex grow basis-[0%] flex-col justify-center items-stretch my-auto">
            <span className="rounded bg-black bg-opacity-10 flex justify-between gap-5 py-px items-start">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/fedc936b5a0d3a99aca53abdf4ea755752a0023bfd80ffa5772a61a71d387fc9?apiKey=f28582526909464db7f31fc277be89ee&"
                className="aspect-[0.96] object-contain object-center w-6 overflow-hidden shrink-0 max-w-full"
              />
              <div className="text-neutral-500 text-base leading-4 mix-blend-luminosity self-center grow shrink basis-auto my-auto">
                Search by name, ID, Kingdom
              </div>
            </span>
          </div>
        </div> */}
        <div className="flex">
          <dir className="flex justify-center">
            <img src={All} alt="iconAll" />
          </dir>
        </div>
      </span>
    </div>
  );
};

export default Header;
