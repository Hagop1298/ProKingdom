import React from "react";
import { Space, Table, Tag, Button } from "antd";
import { createClient } from "@supabase/supabase-js";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../index.css";

console.log(process.env.REACT_APP_GOVERNORS_SUPABASE_URL);

const supabase = createClient(
  process.env.REACT_APP_SUPABASE_URL,
  process.env.REACT_APP_SUPABASE_KEY
);

const supabase2 = createClient(
  "https://tgpucbwkqhwocqvvwbvm.supabase.co/rest/v1/kvk?select=id",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRncHVjYndrcWh3b2NxdnZ3YnZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODk5NTYzMTUsImV4cCI6MjAwNTUzMjMxNX0.bd2zr1eCbTAvUfyHR5HBIVm3zUv9Yw2b7OVT5zOejzc"
);

const MainTable = ({ user }) => {
  const navigate = useNavigate();
  const [governors, setGovernors] = useState([]);
  const [dateTables, setDateTables] = useState({});
  const [loading, setLoading] = useState(true);
  const [governorsData, setGovernorsData] = useState([]);
  const [kvkData, setKvkData] = useState([]);
  useEffect(() => {
    if (user) {
      getGovernors();
      getKvks();
    }
  }, [user]);

  useEffect(() => {
    getGovernors();
    getKvks();
  }, []);


  useEffect(() => {
    const fetchKvkData = async () => {
      try {
        const { data, error } = await supabase2.from("kvk").select("*");
        if (error) {
          throw error;
        }
        setKvkData(data);
      } catch (error) {
        console.error("Error fetching kvk data:", error);
      }
    };

    const fetchGovernorsData = async () => {
      try {
        const { data, error } = await supabase.from("governors").select("*");
        if (error) {
          throw error;
        }
        setGovernorsData(data);
      } catch (error) {
        console.error("Error fetching Governors data:", error);
      }
    };

    fetchKvkData();
    fetchGovernorsData();
  }, []);

  const filteredGovernorsData = kvkData.map((kvkItem) => {
    const filteredGovernors = governorsData.filter(
      (governorItem) => governorItem.kingdom_id === kvkItem.kingdom_id
    );
    return {
      ...kvkItem,
      governors: filteredGovernors,
    };
  });

  async function getGovernors() {
    try {
      const { data, error } = await supabase
        .from("governors")
        .select("*")
        .range(0, 4);

      if (error) {
        console.log("error ==>", error);
        throw error;
      }

      setGovernors(data);
    } catch (error) {
      console.error("Error fetching governors:==>", error);
    } finally {
      setLoading(false);
    }
  }
  const handleLoadMore = () => {
    navigate("/signin");
  };

  // async function getKvks() {
  //   try {
  //     setLoading(true);
  //     const { data, error } = await supabase2.from("kvk").select("*");
  //     if (error) {
  //       console.log("Error fetching kvk:", error);
  //       throw error;
  //     }

  //     const sameDate = [];
  //     const differentDate = [];
  //     const currentDateStr = new Date().toISOString().slice(0, 10);

  //     data.forEach((item) => {
  //       const itemDateStr = new Date(item.created_at)
  //         .toISOString()
  //         .slice(0, 10);

  //       if (itemDateStr === currentDateStr) {
  //         sameDate.push(item);
  //       } else {
  //         differentDate.push(item);
  //       }
  //     });

  //     setSameDate(sameDate);
  //     setDifferentDate(differentDate);
  //   } catch (e) {
  //     console.error("Error fetching kvk:", e);
  //   } finally {
  //     setLoading(false);
  //   }
  // }

  // async function getKvks() {
  //   try {
  //     setLoading(true);
  //     const { data, error } = await supabase2.from("kvk").select("*");

  //     if (error) {
  //       console.log("Error fetching kvk:", error);
  //       throw error;
  //     }
  //     const dateToDataMap = new Map();
  //     data.forEach((item) => {
  //       const createdAtDate = new Date(item.created_at)
  //         .toISOString()
  //         .slice(0, 10);
  //       if (dateToDataMap.has(createdAtDate)) {
  //         dateToDataMap.get(createdAtDate).push(item);
  //       } else {
  //         dateToDataMap.set(createdAtDate, [item]);
  //       }
  //     });

  //     const sameDate = [];
  //     const differentDate = [];
  //     for (const [date, dataArray] of dateToDataMap) {
  //       if (date === "2024-01-15") {
  //         sameDate.push(...dataArray);
  //       } else {
  //         differentDate.push(...dataArray);
  //       }
  //     }
  //     setSameDate(sameDate);
  //     setDifferentDate(differentDate);
  //   } catch (e) {
  //     console.error("Error fetching kvk:", e);
  //   } finally {
  //     setLoading(false);
  //   }
  // }

  // the latest one

  async function getKvks() {
    try {
      setLoading(true);
      const { data, error } = await supabase2.from("kvk").select("*");

      if (error) {
        console.log("Error fetching kvk:", error);
        throw error;
      }
      const dateToDataMap = new Map();
      data.forEach((item) => {
        const createdAtDate = new Date(item.created_at)
          .toISOString()
          .slice(0, 10);
        if (!dateToDataMap.has(createdAtDate)) {
          dateToDataMap.set(createdAtDate, []);
        }
        dateToDataMap.get(createdAtDate).push(item);
      });
      const dateTables = Object.fromEntries(dateToDataMap);

      setDateTables(dateTables);
    } catch (e) {
      console.error("Error fetching kvk:", e);
    } finally {
      setLoading(false);
    }
  }

  const columns = [
    {
      title: "Rank",
      dataIndex: "Rank",
      key: "Rank",
      render: (_, record) => record.Rank,
    },
    {
      title: "Kingdom",
      dataIndex: "Kingdom",
      key: "Kingdom",
      render: (_, record) => record.Kingdom,
    },
    {
      title: "Name",
      dataIndex: "Name",
      key: "Name",
      render: (_, record) => record.Name,
    },
    {
      title: "ID",
      key: "ID",
      dataIndex: "ID",
      render: (_, record) => record.Governor_ID,
    },
    {
      title: "Starting Power",
      dataIndex: "Starting Power",
      key: "Starting Power",
      render: (_, record) => record.Power,
    },
    {
      title: "KP gain",
      dataIndex: "KP gain",
      key: "KP gain",
    },
  ];
  const columns2 = [
    {
      title: "created_at",
      dataIndex: "created_at",
      key: "created_at",
      render: (_, record) => record.created_at,
    },
    {
      title: "Kingdom_id",
      dataIndex: "Kingdom_id",
      key: "Kingdom_id",
      render: (_, record) => record.kingdom_id,
    },
    {
      title: "kvk_id",
      dataIndex: "kvk_id",
      key: "kvk_id",
      render: (_, record) => record.kvk_id,
    },
  ];
  const columns3 = [
    {
      title: "Kvk ID",
      dataIndex: "kvk_id",
      key: "kvk_id",
    },
    {
      title: "Kingdom ID",
      dataIndex: "kingdom_id",
      key: "kingdom_id",
    },
    {
      title: "Governors",
      dataIndex: "governors",
      key: "governors",
      render: (governors) => (
        <ul>
          {governors.map((governor) => (
            <li key={governor.id}>{governor.name}</li>
          ))}
        </ul>
      ),
    },
  ];
  return (
    <div className="w-[1323px] flex flex-col">
      <div className="justify-center text-neutral-800 text-2xl font-semibold whitespace-nowrap hagop">
        Map of #&123;C11001&125;
      </div>
      <span className="shadow-sm bg-white flex w-3/4 flex-col items-center mt-2 pl-4 pr-2.5 py-5 rounded-xl">
        <div className="text-black text-2xl">The Story</div>
        <div className="text-black text-base font-light mt-2.5">
          kvk.&123;kvk_Story&125;Lorem ispum Lorem ispumLorem ispum Lorem
          ispumLorem ispum Lorem ispumLorem ispum Lorem.ispumLorem ispum Lorem
          ispumLorem ispum Lorem ispumLorem ispum Lorem ispumLorem ispum{" "}
        </div>
      </span>
      <Table
        className="w-full flex justify-center hagop"
        columns={columns}
        dataSource={governors}
        loading={loading}
        pagination={false}
        rowClassName="custom-row-style"
      />
      {/* <h2>Same Date Table</h2>
      <Table
        className="w-full flex justify-center hagop"
        columns={columns2}
        dataSource={sameDate}
        loading={loading}
        pagination={false}
        rowClassName="custom-row-style"
      />
      <h2>Different Date Table</h2>
      <Table
        className="w-full flex justify-center hagop"
        columns={columns2}
        dataSource={differentDate}
        loading={loading}
        pagination={false}
        rowClassName="custom-row-style"
      /> */}
      {Object.entries(dateTables).map(([date, data]) => (
        <div key={date}>
          <h2>{date}</h2>
          <Table
            className="w-full flex justify-center hagop"
            columns={columns2}
            dataSource={data}
            loading={loading}
            pagination={false}
            rowClassName="custom-row-style"
          />
        </div>
      ))}

      <div>
        <h1 className="text-white">Data from Kvk Table:</h1>
        <Table columns={columns2} dataSource={kvkData} />
        <h1 className="text-white">Data from Governors Table:</h1>
        <Table columns={columns} dataSource={governorsData} />
        <h1 className="text-white">
          Filtered Governors Data based on Kvk's kingdom_id:
        </h1>
        <Table columns={columns3} dataSource={filteredGovernorsData} />
      </div>
      {!user && (
        <div className="text-center mt-4">
          <Button
            type="primary"
            style={{ backgroundColor: "#0056ff", borderColor: "#0056ff" }}
            onClick={handleLoadMore}
          >
            Sign in to see more
          </Button>
        </div>
      )}
    </div>
  );
};
export default MainTable;
