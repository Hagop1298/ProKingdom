import React from "react";
import proKingdoms from "../Assets/icons/ProKingdoms.svg";
import Stars from "../Assets/icons/stars.svg";
import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";

const supabase2 = createClient(
  "https://tgpucbwkqhwocqvvwbvm.supabase.co/rest/v1/kvk?select=id",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRncHVjYndrcWh3b2NxdnZ3YnZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODk5NTYzMTUsImV4cCI6MjAwNTUzMjMxNX0.bd2zr1eCbTAvUfyHR5HBIVm3zUv9Yw2b7OVT5zOejzc"
);

const Sidebar = () => {
  const [kvkIds, setKvkIds] = useState([]);
  const [kvkMaps, setKvkMaps] = useState([]);
  const [selectedMap, setSelectedMap] = useState(null);
  const [mapTableData, setMapTableData] = useState([]);

   const handleMapClick = async (createdAt) => {
     try {
       const { data, error } = await supabase2
         .from("kvk")
         .select("*")
         .eq("created_at", createdAt);

       if (error) {
         throw error;
       }

       if (data) {
         setMapTableData(data);
       }
     } catch (error) {
       console.error("Error fetching map table data:", error);
     }
   };


  useEffect(() => {
    async function fetchKvkMaps() {
      try {
        const { data, error } = await supabase2.from("kvk").select("*");

        if (error) {
          throw error;
        }

        if (data) {
          // Create a Set to store unique created_at dates
          const uniqueDates = new Set();

          // Filter out duplicate created_at dates and store unique dates in the Set
          const uniqueMaps = data.filter((map) => {
            const createdAtDate = new Date(map.created_at)
              .toISOString()
              .slice(0, 10);
            if (!uniqueDates.has(createdAtDate)) {
              uniqueDates.add(createdAtDate);
              return true;
            }
            return false;
          });

          // Group unique maps by created_at date
          const groupedMaps = uniqueMaps.reduce((acc, map) => {
            const createdAtDate = new Date(map.created_at)
              .toISOString()
              .slice(0, 10);
            if (!acc[createdAtDate]) {
              acc[createdAtDate] = [];
            }
            acc[createdAtDate].push(map);
            return acc;
          }, {});

          // Convert grouped maps object to array
          const mapsArray = Object.entries(groupedMaps).map(([date, maps]) => ({
            date,
            maps,
          }));

          setKvkMaps(mapsArray);
        }
      } catch (error) {
        console.error("Error fetching kvk maps:", error);
      }
    }

    fetchKvkMaps();
  }, []);

  return (
    <div className=" text-white w-64 space-y-6 py-7 px-2 fixed inset-y-0 left-0 z-50 transform -translate-x-full md:relative md:translate-x-0 transition duration-200 ease-in-out background-color">
      <div className="self-stretch flex w-full flex-col justify-center pl-8 pr-16 py-1.5 items-start max-md:max-w-full max-md:px-5">
        <img src={proKingdoms} alt="iconAll" />
        <img src={Stars} alt="iconAll" />
      </div>
      <h1 className="text-3xl font-semibold uppercase tracking-wider">
        ProKingdoms
      </h1>
      <div>
        <h3 className="text-white text-2xl	 uppercase font-semibold">
          Game Center
        </h3>
        <a href="#" className="text-white block mt-2">
          RoK
        </a>
      </div>
      <div>
        <h3 className="text-gray-500 text-xs uppercase">Maps</h3>
        {kvkMaps.map(({ date, maps }) => (
          <div key={date}>
            {maps.map((map, index) => (
              <a
                key={index}
                href={`#map-${map.kvk_id}`}
                className="block mt-2"
                onClick={() => {
                  setSelectedMap(map);
                  handleMapClick(map.created_at);
                }}
              >
                Map of #{map.kvk_id}
              </a>
            ))}
          </div>
        ))}
      </div>
      <div className="">
        <button className="text-white border border-blue-500 py-2 px-4 rounded bg-blue-500 ">
          Join our Discord
        </button>
      </div>
      <div>
        <button className="text-white border border-blue-500 py-2 px-4 rounded bg-blue-500">
          Sign-up
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
