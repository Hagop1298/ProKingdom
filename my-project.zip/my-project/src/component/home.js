import React from "react";
import Header from "./header";
import MainTable from "./table";
import Sidebar from "./sidebar";
// import MainTable2 from "./table2";

const Home = () => {
  return (
    <div>
      <Header />
      <div className="app-container">
        <Sidebar />
        <MainTable />
      </div>
    </div>
  );
};

export default Home;
