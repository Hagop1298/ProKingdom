// // ... (imports and supabase initialization)
// import React from "react";
// import { Space, Table, Tag, Button } from "antd";
// import { createClient } from "@supabase/supabase-js";
// import { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import "../index.css";

// const supabase = createClient(
//   "https://tgpucbwkqhwocqvvwbvm.supabase.co",
//   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRncHVjYndrcWh3b2NxdnZ3YnZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODk5NTYzMTUsImV4cCI6MjAwNTUzMjMxNX0.bd2zr1eCbTAvUfyHR5HBIVm3zUv9Yw2b7OVT5zOejzc"
// );

// const supabase2 = createClient(
//   "https://tgpucbwkqhwocqvvwbvm.supabase.co/rest/v1/kvk?select=id",
//   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRncHVjYndrcWh3b2NxdnZ3YnZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODk5NTYzMTUsImV4cCI6MjAwNTUzMjMxNX0.bd2zr1eCbTAvUfyHR5HBIVm3zUv9Yw2b7OVT5zOejzc"
// );

// const MainTable2 = ({ user }) => {
//   const navigate = useNavigate();
//   const [governors, setGovernors] = useState([]);
//   const [dateTables, setDateTables] = useState({});
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     if (user) {
//       getGovernors();
//       getKvks();
//     }
//   }, [user]);

//   async function getGovernors() {
//     try {
//       const { data, error } = await supabase
//         .from("governors")
//         .select("*")
//         .range(0, 4);

//       if (error) {
//         console.log("error ==>", error);
//         throw error;
//       }

//       setGovernors(data);
//     } catch (error) {
//       console.error("Error fetching governors:==>", error);
//     } finally {
//       setLoading(false);
//     }
//   }

//   async function getKvks() {
//     try {
//       setLoading(true);
//       const { data, error } = await supabase2.from("kvk").select("*");

//       if (error) {
//         console.log("Error fetching kvk:", error);
//         throw error;
//       }

//       const dateToDataMap = new Map();

//       data.forEach((item) => {
//         const createdAtDate = new Date(item.created_at)
//           .toISOString()
//           .slice(0, 10);

//         if (!dateToDataMap.has(createdAtDate)) {
//           dateToDataMap.set(createdAtDate, []);
//         }

//         dateToDataMap.get(createdAtDate).push(item);
//       });

//       const newDateTables = Object.fromEntries(dateToDataMap);

//       setDateTables(newDateTables);
//     } catch (e) {
//       console.error("Error fetching kvk:", e);
//     } finally {
//       setLoading(false);
//     }
//   }

//   const columns2 = [
//     {
//       title: "created_at",
//       dataIndex: "created_at",
//       key: "created_at",
//       render: (_, record) => record.created_at,
//     },
//     {
//       title: "Kingdom_id",
//       dataIndex: "Kingdom_id",
//       key: "Kingdom_id",
//       render: (_, record) => record.kingdom_id,
//     },
//     {
//       title: "kvk_id",
//       dataIndex: "kvk_id",
//       key: "kvk_id",
//       render: (_, record) => record.kvk_id,
//     },
//   ];

//   return (
//     <>
//       <Table
//         className="w-full flex justify-center hagop"
//         columns={columns2}
//         dataSource={governors}
//         loading={loading}
//         pagination={false}
//         rowClassName="custom-row-style"
//       />
//       {Object.entries(dateTables).map(([date, data]) => (
//         <div key={date}>
//           <h2>{date}</h2>
//           <Table
//             className="w-full flex justify-center hagop"
//             columns={columns2}
//             dataSource={data}
//             loading={loading}
//             pagination={false}
//             rowClassName="custom-row-style"
//           />
//         </div>
//       ))}
//       {/* {!user && (
//         <div className="text-center mt-4">
//           <Button
//             type="primary"
//             style={{ backgroundColor: "#0056ff", borderColor: "#0056ff" }}
//             onClick={handleLoadMore}
//           >
//             Sign in to see more
//           </Button>
//         </div>
//       )} */}
//     </>
//   );
// };

// export default MainTable2;
